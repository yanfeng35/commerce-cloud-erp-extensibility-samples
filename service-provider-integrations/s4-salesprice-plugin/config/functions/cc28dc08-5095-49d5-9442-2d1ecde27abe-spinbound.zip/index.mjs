export const handler = (input) => {
    const items = input.data?.value ?? [];
    return {
        data: {
            operations: [
                {
                    operationId: "productPrice",
                    data: {
                        products: items.map(item => ({
                            id: item.Product,
                            price: { value: item.NetAmount }
                        }))
                    }
                }
            ]
        }
    };
};
