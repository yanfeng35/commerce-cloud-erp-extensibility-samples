export const handler = (input) => {
    const items = input.data?.value ?? [];

    if (items.length === 0) {
        return {
            data: {
                operations: [
                    {
                        operationId: "determinePrices",
                        data: {
                            salesArea: { salesOrganization: "", distributionChannel: "", division: "" },
                            currency: { code: "" },
                            products: []
                        }
                    }
                ]
            }
        };
    }

    const first = items[0];

    return {
        data: {
            operations: [
                {
                    operationId: "determinePrices",
                    data: {
                        salesArea: {
                            salesOrganization: first.SalesOrganization,
                            distributionChannel: first.DistributionChannel,
                            division: first.Division
                        },
                        currency: {
                            sapCode: first.TransactionCurrency,
                            code: first.TransactionCurrency
                        },
                        products: items.map(item => {
                            const elements = item._SalesPriceElements ?? [];
                            const sorted = elements.slice().sort(
                                (a, b) => Number(a.PricingProcedureCounter) - Number(b.PricingProcedureCounter)
                            );
                            const basePrice = sorted.find(e => e.ConditionType === "");

                            return {
                                id: item.Product,
                                salesMeasureUnit: {
                                    code: item.RequestedQuantitySAPUnit,
                                    isoCode: item.RequestedQuantityISOUnit
                                },
                                quantity: item.RequestedQuantity,
                                customerNumber: item.SoldToParty,
                                price: {
                                    effectiveValue: item.NetAmount,
                                    priceBreakdowns: [
                                        {
                                            type: "BASE_PRICE",
                                            amount: basePrice?.ConditionAmount ?? 0
                                        }
                                    ],
                                    scalePrices: []
                                }
                            };
                        })
                    }
                }
            ]
        }
    };
};
