export const handler = (input) => {
    const items = input.data?.value ?? [];
    return {
        data: {
            operations: [
                {
                    operationId: "determinePrices",
                    data: {
                        products: items.map(item => ({
                            id: item.Product,
                            price: {
                                effectiveValue: item.NetAmount,
                                priceBreakdowns:[
                                    {
                                        type: "BASE_PRICE",
                                        amount: (item._SalesPriceElements ?? [])
                                            .sort((a, b) => Number(a.PricingProcedureCounter) - Number(b.PricingProcedureCounter))
                                            .find(e => e.ConditionType === "")
                                            ?.ConditionAmount ?? 0
                                    }
                                ],
                                scalePrices:[]
                            }
                        }))
                    }
                }
            ]
        }
    };
};
