export const handler = (input) => {
        console.log("[s4salespriceInbound] input: " + JSON.stringify(input, null, 2));
        const s4Response = input?.data ?? {};
        const items = s4Response.value ?? [];
        const priceItems = items.filter(item => !(item._SystemMessages?.length > 0) && item._SalesPriceElements?.length > 0);
        const operations = [];
        const first = items[0] ?? {};
        const salesArea = {
            salesOrganization: first.SalesOrganization ?? "",
            distributionChannel: first.DistributionChannel ?? "",
            division: first.Division ?? ""
        };
        const currency = {
            sapCode: first.TransactionCurrency ?? "",
            code: first.TransactionCurrency ?? ""
        };

        const operationItem = {
            operationId: "determinePrices",
            data: {
                salesArea,
                currency
            }
        }
        if (priceItems.length > 0) {
            operationItem.data.productPrices = priceItems.map(item => {
                const elements = item._SalesPriceElements ?? [];
                const sorted = elements.slice().sort(
                    (a, b) => Number(a.PricingProcedureCounter) - Number(b.PricingProcedureCounter)
                );
                const basePrice = sorted.find(e => e.ConditionType === "");
                return {
                    id: item.Product,
                    salesMeasureUnit: {
                        code: item.RequestedQuantitySAPUnit ?? "",
                        isoCode: item.RequestedQuantityISOUnit ?? ""
                    },
                    quantity: item.RequestedQuantity ?? 0,
                    soldToParty: item.SoldToParty ?? "",
                    price: {
                        effectiveValue: item.NetAmount ?? 0,
                        priceBreakdowns: [
                            {
                                type: "BASE_PRICE",
                                amount: basePrice?.ConditionAmount ?? 0
                            }
                        ],
                        scalePrices: []
                    }
                }
            })
        } else {
            operationItem.data.productPrices = []
        }
        operations.push(operationItem);
        const result = {data: {operations}};
        console.log("[s4salespriceInbound] output: " + JSON.stringify(result, null, 2));
        return result;
    }
;
