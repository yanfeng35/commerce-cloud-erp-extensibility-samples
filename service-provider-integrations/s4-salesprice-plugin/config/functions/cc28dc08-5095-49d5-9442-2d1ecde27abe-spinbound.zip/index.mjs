export const handler = (input) => {
    const s4Response = input?.data ?? {};

    const items = s4Response.value ?? [];
    const priceItems = items.filter(item => !(item._SystemMessages?.length > 0) && item._SalesPriceElements?.length > 0);
    const operations = [];

    if (priceItems.length > 0) {
        const first = priceItems[0] ?? {};
        const salesArea = {
            salesOrganization:      first.SalesOrganization ?? "",
            distributionChannel:    first.DistributionChannel ?? "",
            division:               first.Division ?? ""
        };
        const currency = {
            sapCode:                first.TransactionCurrency ?? "",
            code:                   first.TransactionCurrency ?? ""
        };
        const data = {
            operationId: "determinePrices",
            data: {
                salesArea,
                currency,
                productPrices: priceItems.map(item => {
                    const elements = item._SalesPriceElements ?? [];
                    const sorted = elements.slice().sort(
                        (a, b) => Number(a.PricingProcedureCounter) - Number(b.PricingProcedureCounter)
                    );
                    const basePrice = sorted.find(e => e.ConditionType === "");
                    return {
                        id: item.Product,
                        salesMeasureUnit: {
                            code:       item.RequestedQuantitySAPUnit ?? "",
                            isoCode:    item.RequestedQuantityISOUnit ?? ""
                        },
                        quantity:       item.RequestedQuantity ?? 0,
                        soldToParty:    item.SoldToParty ?? "",
                        price: {
                            effectiveValue: item.NetAmount ?? 0,
                            priceBreakdowns: [
                                {
                                    type: "BASE_PRICE",
                                    amount: basePrice?.ConditionAmount ?? 0
                                }
                            ],
                            scalePrices: []
                        }
                    }
                })
            }
        };
        operations.push(data);
    }

    /*    if (errorItems.length > 0) {
            const messages = errorItems.flatMap(item =>
                item._SystemMessages.map(msg => ({
                    kind: msg.SystemMessageTypeName?.toLowerCase() ?? "error",
                    code: `${msg.SystemMessageNumber} ${msg.SystemMessageType}`,
                    message: msg.SystemMessageText ?? "",
                    target: item.Product
                }))
            );

            operations.push({
                operationId: "addMessages",
                data: {messages}
            });
        }*/
    const result = {data: {operations}};
    return result;
};
