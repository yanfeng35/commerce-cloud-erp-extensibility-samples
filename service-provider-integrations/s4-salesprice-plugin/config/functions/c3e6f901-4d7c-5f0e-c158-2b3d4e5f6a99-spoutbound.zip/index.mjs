export const handler = (input) => {
    const { products, currency, businessPartner, salesArea } = input.data;

    const today = new Date().toISOString().split('T')[0]; // "YYYY-MM-DD"

    return {
        SalesOrganization: salesArea.salesOrganization,
        DistributionChannel: salesArea.distributionChannel,
        Division: salesArea.division,
        TransactionCurrency: currency.code,
        SalesDocumentType: "",
        SalesDocumentItemCategory: "",
        BillingDocumentType: "",
        LanguageISOCode: "",
        SalesPriceRetrieveUseCase: "",
        PriceElementsAreRequested: true,
        PricingDate: today,
        // RequestedQuantity intentionally omitted: CCS ProductResource has no quantity field.
        // S/4 defaults to qty 1. Known business gap — scale/tiered pricing is not supported.
        _Product: products.map(p => ({
            Product: p.id,
            ProductUsedByCustomer: ""
        })),
        _SoldToParty: [{ SoldToParty: businessPartner.customerNumber }]
    };
};
