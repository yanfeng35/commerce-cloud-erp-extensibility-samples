export const handler = (input) => {
    const salesPriceItems = input.value || [];

    const products = salesPriceItems.map(item => ({
        id: item.Product,
        price: {
            value: item.NetAmount,
            scalePrices: [
                {
                    minQuantity: 1,
                    price: item.NetAmount
                }
            ]
        }
    }));

    const operations = [
        {
            operationId: "productPrice",
            data: { products }
        }
    ];

    const messages = salesPriceItems.flatMap(item =>
        (item._SystemMessages || []).map(msg => ({
            kind: msg.SystemMessageType === 'E' ? 'ERROR'
                : msg.SystemMessageType === 'W' ? 'WARNING'
                : 'INFO',
            code: String(msg.SystemMessageNumber),
            message: msg.SystemMessageText,
            target: msg.SystemMessageIdentification || ""
        }))
    );

    if (messages.length > 0) {
        operations.push({ operationId: "addMessages", data: { messages } });
    }

    return { operations };
};
