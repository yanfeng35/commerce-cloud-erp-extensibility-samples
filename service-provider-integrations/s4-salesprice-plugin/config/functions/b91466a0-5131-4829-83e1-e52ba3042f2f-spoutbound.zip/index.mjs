export const handler = (input, configuration) => {

    const data = input?.data ?? {};
    const configMap = (configuration && typeof configuration === "object") ? configuration : {};
    const storeId = input?.commerceContext?.storeId?.trim() ?? "";
    const prefix = `${storeId}.`;
    const configuredSoldToParty = configMap[`${prefix}one-time.customer.id`]?.trim() ?? "";

    const {
        products = [],
        currency = {},
        soldToParty = "",
        salesArea = {},
        pricingAt = ""
    } = data;

    const pricingDate = pricingAt ? pricingAt.split('T')[0] : new Date().toISOString().split('T')[0];

    const result = {
        SalesOrganization: salesArea.salesOrganization ?? "",
        DistributionChannel: salesArea.distributionChannel ?? "",
        Division: salesArea.division ?? "",
        TransactionCurrency: currency.sapCode ?? currency.code ?? "",
        LanguageISOCode: "",
        SalesDocumentType: "",
        SalesDocumentItemCategory: "",
        BillingDocumentType: "",
        SalesPriceRetrieveUseCase: "SAP_DFLT",
        PriceElementsAreRequested: true,
        PricingDate: pricingDate,
        _Product: products.map(p => ({
            Product: p.id,
            ProductUsedByCustomer: "",
            ...(p.quantity != null && {
                RequestedQuantity: p.quantity,
                RequestedQuantityISOUnit: p.salesMeasureUnit?.isoCode ?? "",
                RequestedQuantitySAPUnit: p.salesMeasureUnit?.code ?? ""
            }),
        })),
        _SoldToParty: [{SoldToParty: soldToParty || configuredSoldToParty}]
    };
    return result;
};
