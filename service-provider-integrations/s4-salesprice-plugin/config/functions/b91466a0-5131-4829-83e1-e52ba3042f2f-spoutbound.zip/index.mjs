export const handler = (input) => {
    const { products, currency, businessPartner, salesArea } = input.data;

    const today = new Date().toISOString().split('T')[0];

    return {
        SalesOrganization: salesArea.salesOrganization,
        DistributionChannel: salesArea.distributionChannel,
        Division: salesArea.division,
        TransactionCurrency: currency.code,
        SalesDocumentType: "EOX1",
        SalesDocumentItemCategory: "EDX1",
        BillingDocumentType: "CIX1",
        SalesPriceRetrieveUseCase: "SAP_DFLT",
        LanguageISOCode: "",
        PriceElementsAreRequested: true,
        PricingDate: today,
        _Product: products.map(p => ({
            Product: p.id,
            ProductUsedByCustomer: "",
            ...(p.quantity != null && { RequestedQuantity: p.quantity }),
            ...(p.salesMeasureUnit?.isocode && { RequestedQuantityISOUnit: p.salesMeasureUnit.isocode })
        })),
        _SoldToParty: [{ SoldToParty: businessPartner?.customerNumber ?? "" }]
    };
};
