export const handler = (input) => {
    const { products, currency, customers, salesArea, pricingAt } = input.data;

    const today = new Date().toISOString().split('T')[0];
    const pricingDate = pricingAt ? pricingAt.split('T')[0] : today;

    return {
        SalesOrganization: salesArea.salesOrganization,
        DistributionChannel: salesArea.distributionChannel,
        Division: salesArea.division,
        TransactionCurrency: currency.sapCode,
        LanguageISOCode: "",
        SalesDocumentType: "",
        SalesDocumentItemCategory: "",
        BillingDocumentType: "",
        SalesPriceRetrieveUseCase: "SAP_DFLT",
        PriceElementsAreRequested: true,
        PricingDate: pricingDate,
        _Product: products.map(p => ({
            Product: p.id,
            ProductUsedByCustomer: "",
            ...(p.quantity != null && {
                RequestedQuantity: p.quantity,
                RequestedQuantityISOUnit: p.salesMeasureUnit?.isocode ?? "",
                RequestedQuantitySAPUnit: p.salesMeasureUnit?.code ?? ""
            }),
        })),
        _SoldToParty: (customers ?? []).map(c => ({ SoldToParty: c.customerNumber }))
    };
};
